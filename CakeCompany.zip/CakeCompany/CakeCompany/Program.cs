﻿// See https://aka.ms/new-console-template for more information

using CakeCompany.Provider;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;

ILoggerFactory loggerFactory = LoggerFactory.Create(builder =>
{
    builder.AddConsole();

});
var logger = loggerFactory.CreateLogger<ShipmentProvider>();
var orderProvider = new OrderProvider();
var transportProvider = new TransportProvider();
var cakeProvider = new CakeProvider();
var paymentProvider = new PaymentProvider();
var shipmentProvider = new ShipmentProvider(logger,orderProvider,cakeProvider,transportProvider,paymentProvider);
shipmentProvider.GetShipment();
logger.LogInformation("Shipment Details...");
