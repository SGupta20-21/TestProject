﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Provider;
using CakeCompany.Provider.Interface;
using CakeCompany.Service.Factory;
using Microsoft.Extensions.Logging;
using System.Reflection;

namespace CakeCompany.Service;

internal class OrderHelperService
{
    private readonly ILogger _logger;
    private readonly ICakeProvider _cakeProvider;
    private readonly IPaymentProvider _paymentProvider;


    public OrderHelperService(ILogger logger,ICakeProvider cakeProvider, IPaymentProvider paymentProvider)
    {
        _logger = logger ?? throw new ArgumentNullException("Logger");
        _cakeProvider = cakeProvider ?? throw new ArgumentNullException("CakeProvider"); 
        _paymentProvider = paymentProvider ?? throw new ArgumentNullException("PaymentProvider"); ;
    }
    internal  bool  VerifyOrders(Order order, ICakeProvider cakeProvider, List<Order> CancelledOrder,IPaymentProvider payment)
    {
        try
        {
            string methodName = MethodBase.GetCurrentMethod().Name;
            LogEnteredMethod(methodName);
            var estimatedBakeTime = cakeProvider.Check(order);
            if (estimatedBakeTime > order.EstimatedDeliveryTime)
            {
                CancelledOrder.Add(order);
                _logger.LogError("Cancelled Order due to baketime greatar than delivery time" + order);
                return false;
            }
            if (!payment.Process(order).IsSuccessful)
            {
                CancelledOrder.Add(order);
                _logger.LogError("Cancelled Order due to payment not successful" + order);
                return false;
            }
            LogExitMethod(methodName);
            return true;
        }
        catch (Exception)
        {
            _logger.LogError("Error occured in VerifyOrders Method");
            throw;
        }

    }
    internal Product ProcessOrders(ICakeProvider cakeProvider, Order order)
    {
        try
        {
            string methodName = MethodBase.GetCurrentMethod().Name;
            LogEnteredMethod(methodName);
            var product = cakeProvider.Bake(order);
            _logger.LogInformation("Process order" + order);
            LogExitMethod(methodName);
            return product;
        }
        catch (Exception)
        {
            _logger.LogError("Error occured in ProcessOrders Method");
            throw;
        }
    }

    private void LogEnteredMethod(string methodName)
    {
        _logger.LogInformation("Entered " + methodName);
    }
    private void LogExitMethod(string methodName)
    {
        _logger.LogInformation("Exit " + methodName);
    }

}