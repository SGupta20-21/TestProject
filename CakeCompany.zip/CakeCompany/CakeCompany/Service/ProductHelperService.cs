﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Provider.Interface;
using CakeCompany.Service.Factory;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Service;

internal class ProductHelperService
{

    private readonly ILogger _logger;
    private readonly ITransportProvider _transportProvider;
    public ProductHelperService(ILogger logger, ITransportProvider transportProvider)
    {
        _logger = logger ?? throw new ArgumentNullException("Logger");
        _transportProvider = transportProvider ?? throw new ArgumentNullException("TransportProvider");
    }
    internal bool DeliverProducts(List<Product> products)
    {
        var DeliveryStatus = false;
        try
        {
            string methodName = MethodBase.GetCurrentMethod().Name;
            LogEnteredMethod(methodName);
            var transport = _transportProvider.CheckForAvailability(products);
            IVehicle vehicle = new ConcreteTransportFactory().GetTransport(transport);
            if (vehicle != null)
            {
                vehicle.Deliver(products);
                DeliveryStatus = true;
                return DeliveryStatus;
            }
            LogExitMethod(methodName);
        }
        catch (Exception)
        {
            _logger.LogError("Error occured in DeliverProducts Method");
            throw;
        }
        return DeliveryStatus;
    }

    private void LogEnteredMethod(string methodName)
    {
        _logger.LogInformation("Entered " + methodName);
    }
    private void LogExitMethod(string methodName)
    {
        _logger.LogInformation("Exit " + methodName);
    }

}
