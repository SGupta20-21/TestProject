﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Service.Factory;

internal abstract class TransportFactoryBase
{
    public abstract IVehicle GetTransport(VehicleType trasport);

}
