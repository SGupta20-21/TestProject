﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Service.Factory;

internal class ConcreteTransportFactory : TransportFactoryBase
{
    public override IVehicle GetTransport(VehicleType transport)
    {
        IVehicle vehicle;
        switch (transport)
        {
            case VehicleType.Van:
                vehicle = new Van();
                break;


            case VehicleType.Truck:
                vehicle = new Truck();
                break;

            case VehicleType.Ship:
                vehicle = new Ship();
                break;

            default:
                vehicle = null;
                break;
        }
        return vehicle;
    }
}
