﻿namespace CakeCompany.Models.Transport;

internal class Ship:IVehicle
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}