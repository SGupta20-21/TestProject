﻿namespace CakeCompany.Models.Transport;

internal class Van : IVehicle
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}