﻿namespace CakeCompany.Models.Transport;

internal class Truck:IVehicle
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}