﻿namespace CakeCompany.Models;

public class PaymentIn
{
    public bool IsSuccessful { get; set; }
    public bool HasCreditLimit { get; set; }
}
