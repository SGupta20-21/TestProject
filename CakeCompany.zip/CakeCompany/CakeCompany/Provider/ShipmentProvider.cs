﻿using System.Diagnostics;
using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Service;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Reflection;
using CakeCompany.Provider.Interface;

namespace CakeCompany.Provider;

internal class ShipmentProvider
{
    private readonly ILogger _logger;
    private readonly IOrderProvider _orderProvider;
    private readonly ITransportProvider _transportProvider;
    private readonly ICakeProvider _cakeProvider;
    private readonly IPaymentProvider _paymentProvider;


    public ShipmentProvider(ILogger logger,IOrderProvider orderProvider,ICakeProvider cakeProvider,ITransportProvider transportProvider, IPaymentProvider paymentProvider)
    {
        _logger = logger ?? throw new ArgumentNullException("ShipmentProviderlogger");
        _orderProvider = orderProvider ?? throw new ArgumentNullException("OrderProvider");
        _transportProvider = transportProvider ?? throw new ArgumentNullException("TransportProvider");
        _cakeProvider = cakeProvider ?? throw new ArgumentNullException("CakeProvider");
        _paymentProvider = paymentProvider ?? throw new ArgumentNullException("PaymentProvider");
    }

    internal bool GetShipment()
    {        
        var ShipmentStatus = false;
        try
        {
            string methodName = MethodBase.GetCurrentMethod().Name;
            LogEnteredMethod(methodName);
            Order[] orders = _orderProvider.GetLatestOrders();
            if (!orders.Any())
            {
                return ShipmentStatus;
            }
            var cancelledOrders = new List<Order>();
            var products = new List<Product>();           
            var orderService = new OrderHelperService(_logger,_cakeProvider,_paymentProvider);
            var productService = new ProductHelperService(_logger, _transportProvider);
            foreach (var (order, orderstatus) in from order in orders
                                                 let orderstatus = orderService.VerifyOrders(order, _cakeProvider, cancelledOrders, _paymentProvider)
                                                 select (order, orderstatus))
            {
                _logger.LogInformation("Order Status is " + orderstatus);
                if (orderstatus)
                {
                    AddProductToDeliver(products, _cakeProvider, orderService, order);
                }
            }
            if (products.Any())
            {
                ShipmentStatus = productService.DeliverProducts(products);
                _logger.LogInformation("Products Delivered  ");
            }
            LogExitMethod(methodName);
            return ShipmentStatus;
        }
        catch (Exception)
        {
            _logger.LogError("Error Occurred");
            throw;
        }
    }

    private void AddProductToDeliver(List<Product> products, ICakeProvider cakeProvider, OrderHelperService orderService, Order? order)
    {
        var product = orderService.ProcessOrders(cakeProvider, order);
        if (product is not null)
        {
            products.Add(product);
            _logger.LogInformation("Processed added Product  " + product.Id);
        }
    }

    private void LogEnteredMethod(string methodName)
    {
        _logger.LogInformation("Entered " + methodName);
    }
    private void LogExitMethod(string methodName)
    {
        _logger.LogInformation("Exit " + methodName);
    }

}
