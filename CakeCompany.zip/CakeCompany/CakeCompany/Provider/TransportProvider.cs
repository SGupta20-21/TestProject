﻿using CakeCompany.Models;
using CakeCompany.Provider.Interface;

namespace CakeCompany.Provider;


internal class TransportProvider : ITransportProvider
{
    public VehicleType CheckForAvailability(List<Product> products)
    {
        if (products.Sum(p => p.Quantity) < 1000)
        {
            return VehicleType.Van;
        }

        if (products.Sum(p => p.Quantity) > 1000 && products.Sum(p => p.Quantity) < 5000)
        {
            return VehicleType.Truck;
        }

        return VehicleType.Ship;
    }
}
