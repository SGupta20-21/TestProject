﻿using CakeCompany.Models;

namespace CakeCompany.Provider.Interface;

public interface ICakeProvider
{
    Product Bake(Order order);
    DateTime Check(Order order);
}