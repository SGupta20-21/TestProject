﻿using CakeCompany.Models;

namespace CakeCompany.Provider.Interface
{
    public interface ITransportProvider
    {
        VehicleType CheckForAvailability(List<Product> products);
    }
}