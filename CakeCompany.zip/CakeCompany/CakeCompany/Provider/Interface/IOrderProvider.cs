﻿using CakeCompany.Models;

namespace CakeCompany.Provider.Interface;

public interface IOrderProvider
{
    Order[] GetLatestOrders();
    void UpdateOrders(Order[] orders);
}