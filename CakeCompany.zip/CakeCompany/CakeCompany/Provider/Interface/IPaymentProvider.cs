﻿using CakeCompany.Models;

namespace CakeCompany.Provider.Interface;

public interface IPaymentProvider
{
    PaymentIn Process(Order order);
}