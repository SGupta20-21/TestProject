﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CakeCompany.Models;
using CakeCompany.Provider.Interface;
using CakeCompany.Service;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;

namespace CakeCompany.UnitTest.Service;

[TestFixture]
public class ProductHelperServiceTest
{
    private ProductHelperService? _ProductService;
    private Mock<ILogger>? loggermock;
    private Mock<ITransportProvider>? transportProvider;


    [SetUp]
    public void SetUp()
    {
        loggermock = new Mock<ILogger>();
        transportProvider = new Mock<ITransportProvider>();
        _ProductService = new ProductHelperService(loggermock.Object, transportProvider.Object);
    }

    [Test]
    public void DeliverProducts_InputValidOrder_Vehicle_Van_ReturnTrue()
    {
        var ret = false;
        //Arrange
        var products = new List<Product>();
        products.AddRange(new List<Product>{
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 1
            },
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 2
            },
        });
        transportProvider.Setup(x => x.CheckForAvailability(It.IsAny<List<Product>>()))
            .Returns(VehicleType.Van);
        //Act
        if (_ProductService is not null)
        {
            ret = _ProductService.DeliverProducts(products);
        }
        //Assert
        Assert.IsTrue(ret);
    }
    [Test]
    public void DeliverProducts_InputValidOrder_Vehicle_Blank_ReturnFalse()
    {
        var ret = false;
        //Arrange
        var products = new List<Product>();
        products.AddRange(new List<Product>{
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 1
            },
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 2
            },
        });
        transportProvider.Setup(x => x.CheckForAvailability(It.IsAny<List<Product>>()))
            .Returns(VehicleType.Unknown);
        //Act
        if (_ProductService is not null)
        {
            ret = _ProductService.DeliverProducts(products);
        }
        //Assert
        Assert.IsFalse(ret);
    }


}

