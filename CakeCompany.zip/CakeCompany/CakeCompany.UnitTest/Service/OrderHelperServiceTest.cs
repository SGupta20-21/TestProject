﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CakeCompany.Models;
using CakeCompany.Provider;
using CakeCompany.Provider.Interface;
using CakeCompany.Service;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;

namespace CakeCompany.UnitTest.Service;

[TestFixture]
public class OrderHelperServiceTest
{
    private OrderHelperService? _OrderService;
    private Mock<ILogger>? loggermock;
    private Mock<ICakeProvider>? cakeProvider;
    private Mock<IPaymentProvider>? paymentProvider;



    [SetUp]
    public void SetUp()
    {
        loggermock = new Mock<ILogger>();
        cakeProvider = new Mock<ICakeProvider>();
        paymentProvider = new Mock<IPaymentProvider>();
        _OrderService = new OrderHelperService(loggermock.Object, cakeProvider.Object,paymentProvider.Object);
    }

    [Test]
    public void VerifyOrders_InputInValidOrder_ReturnFalse_CancelledOrderCount()
    {
        var ret = false;
        var estimatedBakeTime = DateTime.Now.AddMinutes(60);
        //Arrange
        var orderstub = new Mock<Order>("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25);
      
        var cancelledOrderStub = new Mock<List<Order>>();
        cakeProvider.Setup(x => x.Check(It.IsAny<Order>()))
            .Returns(estimatedBakeTime);
        paymentProvider.Setup(x => x.Process(It.IsAny<Order>()))
            .Returns(new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = true
            });
        //Act
        if (_OrderService is not null)
        {
            ret = _OrderService.VerifyOrders(orderstub.Object, cakeProvider.Object, cancelledOrderStub.Object, paymentProvider.Object);
        }
        //Assert
        Assert.IsFalse(ret);
        Assert.AreEqual(cancelledOrderStub.Object.Count, 1);
    }

    [Test]
    public void VerifyOrders_InputValidOrder_ReturnTrue()
    {
        var ret = false;
        var estimatedBakeTime = DateTime.Now.AddMinutes(30);
        //Arrange
        var orderstub = new Mock<Order>("CakeBox", DateTime.Now.AddHours(1), 1, Cake.Chocolate, 120.25);
        var cancelledOrderStub = new Mock<List<Order>>();
        cakeProvider.Setup(x => x.Check(It.IsAny<Order>()))
            .Returns(estimatedBakeTime);
        paymentProvider.Setup(x => x.Process(It.IsAny<Order>()))
            .Returns(new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = true
            });
        //Act
        if (_OrderService is not null)
        {
            ret = _OrderService.VerifyOrders(orderstub.Object, cakeProvider.Object, cancelledOrderStub.Object, paymentProvider.Object);
        }
        //Assert
        Assert.IsTrue(ret);
    }

    [Test]
    public void ProcessOrders_InputValidOrder_ReturnChoclateProduct()
    {
        Product product;
        //Arrange
        var orderstub = new Mock<Order>("CakeBox", DateTime.Now.AddHours(1), 1, Cake.Chocolate, 120.25);        
        cakeProvider.Setup(x => x.Bake(It.IsAny<Order>()))
            .Returns(
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 1
            }
            );
        paymentProvider.Setup(x => x.Process(It.IsAny<Order>()))
            .Returns(new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = true
            });

        //Act
        if (_OrderService is not null)
        {
            product = _OrderService.ProcessOrders(cakeProvider.Object, orderstub.Object);
            //Assert
            Assert.AreEqual(product.Cake, Cake.Chocolate);
        }

    }

}

