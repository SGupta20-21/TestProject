﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CakeCompany.Models;
using CakeCompany.Provider;
using Moq;
using NUnit.Framework;

namespace CakeCompany.UnitTest.Provider;

[TestFixture]
public class TransportProviderTest
{
    private TransportProvider? _transportProvider;

    [SetUp]
    public void SetUp()
    {
        _transportProvider = new TransportProvider();
    }

    [Test]
    public void CheckForAvailability_InputValidProduct_ReturnShip()
    {
        var ret = default(VehicleType);
        //Arrange
        var products = new List<Product>();
        products.AddRange(new List<Product>{
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 1
            },
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 5000
            },
        });

        //Act
        if (_transportProvider is not null)
        {
            ret = _transportProvider.CheckForAvailability(products);
        }
        //Assert
        Assert.AreEqual(VehicleType.Ship, ret);
    }

    [Test]
    public void CheckForAvailability_InputValidProduct_ReturnTruck()
    {
        var ret = default(VehicleType);
        //Arrange
        var products = new List<Product>();
        products.AddRange(new List<Product>{
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 2
            },
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 999
            },
        });


        //Act
        if (_transportProvider is not null)
        {
            ret = _transportProvider.CheckForAvailability(products);
        }
        //Assert
        Assert.AreEqual(VehicleType.Truck, ret);
    }

    [Test]
    public void CheckForAvailability_InputValidProduct_ReturnVan()
    {
        var ret = default(VehicleType);
        //Arrange
        var products = new List<Product>();
        products.AddRange(new List<Product>{
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 9
            },
            new Product()
            {
                Cake = Cake.Chocolate,
                Id = new Guid(),
                Quantity = 2
            },
        });

        //Act
        if (_transportProvider is not null)
        {
            ret = _transportProvider.CheckForAvailability(products);
        }
        //Assert
        Assert.AreEqual(VehicleType.Van, ret);
    }


}


