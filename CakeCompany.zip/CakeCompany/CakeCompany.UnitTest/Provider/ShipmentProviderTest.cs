﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CakeCompany.Models;
using CakeCompany.Provider;
using CakeCompany.Provider.Interface;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;

namespace CakeCompany.UnitTest.Provider;

[TestFixture]
public class ShipmentProviderTest
{
    private ShipmentProvider? _shipmentProvider;
    private Mock<ILogger>? loggermock;
    private Mock<IOrderProvider>? orderProvider;
    private Mock<ICakeProvider>? cakeProvider;
    private Mock<ITransportProvider>? transportProvider;
    private Mock<IPaymentProvider>? paymentProvider;



    [SetUp]
    public void SetUp()
    {
        loggermock = new Mock<ILogger>();
        orderProvider = new Mock<IOrderProvider>();
        cakeProvider = new Mock<ICakeProvider>();
        transportProvider = new Mock<ITransportProvider>();
        paymentProvider = new Mock<IPaymentProvider>();
        _shipmentProvider = new ShipmentProvider(loggermock.Object, orderProvider.Object, cakeProvider.Object, transportProvider.Object,paymentProvider.Object);
    }
   
    [Test]
    public void GetShipment_InputZeroOrder_ReturnFalse()
    {
        var ret = false;
        //Arrange
        orderProvider.Setup(x => x.GetLatestOrders())
                             .Returns(new Order[]
                     {
                     });
        //Act
        if (_shipmentProvider is not null)
        {
            ret = _shipmentProvider.GetShipment();
        }
        //Assert
        Assert.IsFalse(ret);

    }

    [Test]
    public void GetShipment_InputValidOrder_ReturnTrue()
    {
        var ret = false;
        //Arrange
        DateTime t = DateTime.Now.AddHours(2);
        var estimatedBakeTime = DateTime.Now;
        orderProvider.Setup(x => x.GetLatestOrders())
                            .Returns(new Order[]
                    {
                        new("CakeBox", t, 1, Cake.RedVelvet, 120.25),
                    });
        cakeProvider.Setup(x => x.Check(It.IsAny<Order>()))
           .Returns(estimatedBakeTime);
        cakeProvider.Setup(x => x.Bake(It.IsAny<Order>()))
            .Returns(
            new Product()
            {
                Cake = Cake.RedVelvet,
                Id = new Guid(),
                Quantity = 1
            }
            );
        paymentProvider.Setup(x => x.Process(It.IsAny<Order>()))
            .Returns(new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = true
            });

        transportProvider.Setup(x => x.CheckForAvailability(It.IsAny<List<Product>>()))
         .Returns(VehicleType.Van);

        if (_shipmentProvider is not null)
        {
            ret = _shipmentProvider.GetShipment();
        }
        Assert.IsTrue(ret);
    }
    [Test]
    public void GetShipment_InputInValidOrder_BakeTime_greaterthan_deliverytime_ReturnFalse()
    {
        var ret = false;
        var estimatedBakeTime = DateTime.Now.AddMinutes(60);
        //Arrange           
        orderProvider.Setup(x => x.GetLatestOrders())
                 .Returns(new Order[]
         {
        new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25),
        new("ImportantCakeShop", DateTime.Now, 1, Cake.RedVelvet, 120.25)
         });
        cakeProvider.Setup(x => x.Check(It.IsAny<Order>()))
            .Returns(estimatedBakeTime);

        //Act
        if (_shipmentProvider is not null)
        {
            ret = _shipmentProvider.GetShipment();
        }
        //Assert
        Assert.IsFalse(ret);
    }

    [Test]
    public void GetShipment_InputInValidOrder_Bake_Noproductreturn_ReturnFalse()
    {
        var ret = false;
        var t = DateTime.Now.AddMinutes(60);
        var estimatedBakeTime = DateTime.Now;
        //Arrange           
        orderProvider.Setup(x => x.GetLatestOrders())
                 .Returns(new Order[]
         {
        new("CakeBox", t, 1, Cake.RedVelvet, 120.25),
        new("ImportantCakeShop", t, 1, Cake.RedVelvet, 120.25)
         });
        cakeProvider.Setup(x => x.Check(It.IsAny<Order>()))
            .Returns(estimatedBakeTime);
        cakeProvider.Setup(x => x.Bake(It.IsAny<Order>()))
        .Returns(
        value: null as Product);
        transportProvider.Setup(x => x.CheckForAvailability(It.IsAny<List<Product>>()))
         .Returns(VehicleType.Van);
        paymentProvider.Setup(x => x.Process(It.IsAny<Order>()))
            .Returns(new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = true
            });

        //Act
        if (_shipmentProvider is not null)
        {
            ret = _shipmentProvider.GetShipment();
        }
        //Assert
        Assert.IsFalse(ret);
    }

    [Test]
    public void GetShipment_InputInValidOrder_Unknown_Vehicle_ReturnFalse()
    {
        var ret = false;
        var t = DateTime.Now.AddMinutes(60);
        var estimatedBakeTime = DateTime.Now;
        //Arrange           
        orderProvider.Setup(x => x.GetLatestOrders())
                 .Returns(new Order[]
         {
        new("CakeBox", t, 1, Cake.RedVelvet, 120.25),
         });
        cakeProvider.Setup(x => x.Check(It.IsAny<Order>()))
            .Returns(estimatedBakeTime);
        cakeProvider.Setup(x => x.Bake(It.IsAny<Order>()))
        .Returns(
        new Product()
        {
            Cake = Cake.RedVelvet,
            Id = new Guid(),
            Quantity = 1
        });
        transportProvider.Setup(x => x.CheckForAvailability(It.IsAny<List<Product>>()))
         .Returns(VehicleType.Unknown);
        paymentProvider.Setup(x => x.Process(It.IsAny<Order>()))
            .Returns(new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = true
            });
        //Act
        if (_shipmentProvider is not null)
        {
            ret = _shipmentProvider.GetShipment();
        }
        //Assert
        Assert.IsFalse(ret);
    }
    [Test]
    public void GetShipment_InputValidOrder_PaymentNotSucessful_ReturnFalse()
    {
        var ret = false;
        //Arrange
        DateTime t = DateTime.Now.AddHours(2);
        var estimatedBakeTime = DateTime.Now;
        orderProvider.Setup(x => x.GetLatestOrders())
                            .Returns(new Order[]
                    {
                        new("CakeBox", t, 1, Cake.RedVelvet, 120.25),
                    });
        cakeProvider.Setup(x => x.Check(It.IsAny<Order>()))
           .Returns(estimatedBakeTime);
        cakeProvider.Setup(x => x.Bake(It.IsAny<Order>()))
            .Returns(
            new Product()
            {
                Cake = Cake.RedVelvet,
                Id = new Guid(),
                Quantity = 1
            }
            );
        paymentProvider.Setup(x => x.Process(It.IsAny<Order>()))
            .Returns(new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = false
            });

        transportProvider.Setup(x => x.CheckForAvailability(It.IsAny<List<Product>>()))
         .Returns(VehicleType.Van);

        if (_shipmentProvider is not null)
        {
            ret = _shipmentProvider.GetShipment();
        }
        Assert.IsFalse(false);
    }
}

    
