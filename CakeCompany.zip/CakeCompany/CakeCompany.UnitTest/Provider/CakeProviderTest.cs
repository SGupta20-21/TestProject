﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CakeCompany.Models;
using CakeCompany.Provider;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;

namespace CakeCompany.UnitTest.Provider;

[TestFixture]
public class CakeProviderTest
{
    private CakeProvider? _CakeProvider;


    [SetUp]
    public void SetUp()
    {
        _CakeProvider = new CakeProvider();
    }
    [Test]
    public void Check_InputValidRedValvetCakeOrder_ReturnGreaterDate()
    {
        var currenttimestamp = DateTime.Now;
        var deliverytimestamp = DateTime.Now;
        //Arrange
        var order = new Mock<Order>("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25);

        //Act
        if (_CakeProvider is not null)
        {
            deliverytimestamp = _CakeProvider.Check(order.Object);
        }
        //Assert
        var remainingtime = deliverytimestamp - currenttimestamp;
        Assert.GreaterOrEqual(remainingtime.TotalMinutes, 60);
    }

    [Test]
    public void Check_InputValidChoclateCakeOrder_ReturnGreaterDate()
    {
        var currenttimestamp = DateTime.Now;
        var deliverytimestamp = DateTime.Now;
        //Arrange
        var order = new Mock<Order>("CakeBox", DateTime.Now, 1, Cake.Chocolate, 120.25);
        //Act
        if (_CakeProvider is not null)
        {
            deliverytimestamp = _CakeProvider.Check(order.Object);
        }
        //Assert
        var remainingtime = deliverytimestamp - currenttimestamp;
        Assert.GreaterOrEqual(remainingtime.TotalMinutes, 30);
    }

    [Test]
    public void Check_InputValidOtherCakeOrder_ReturnGreaterDate()
    {
        var currenttimestamp = DateTime.Now;
        var deliverytimestamp = DateTime.Now;
        //Arrange
        var order = new Mock<Order>("CakeBox", DateTime.Now, 1, Cake.Vanilla, 120.25);
        //Act
        if (_CakeProvider is not null)
        {
            deliverytimestamp = _CakeProvider.Check(order.Object);
        }
        //Assert
        var remainingtime = deliverytimestamp - currenttimestamp;
        Assert.GreaterOrEqual(remainingtime.TotalMinutes, 15);
    }

}

